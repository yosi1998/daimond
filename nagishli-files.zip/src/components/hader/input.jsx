import Modal from "react-bootstrap/Modal";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import {faMagnifyingGlass,} from "@fortawesome/free-solid-svg-icons";



function Input(props) {
  return (
    <Modal
      {...props}
      size="md"
    >
       <Modal.Header className="border border-0" closeButton />
              <div className="input-group p-4">
                <button className="btn btnTwo" type="button" id="button-addon1">
                  <FontAwesomeIcon icon={faMagnifyingGlass} size="lg" />
                </button>
                <input
                  dir="rtl"
                  type="search"
                  className="form-control"
                  placeholder="לחפש..."
                />
              </div>
    </Modal>
  );
}

export default Input;







