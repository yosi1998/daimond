// WelcomeMessageOverlay.js

import React from "react";
import "./welcomeMessageOverlay.css"

const WelcomeMessageOverlay = ({ username }) => {
  return (
    <div className="overlay">
      <div className="welcome-message-modal">
        <p>ברוך הבא, {username}!</p>
       <p>הרשמת בוצעה בהצלחה</p>
      </div>
    </div>
  );
};

export default WelcomeMessageOverlay;
