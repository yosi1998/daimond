import React from 'react'

const Logo = () => {
  return (
    <div className='d-flex justify-content-center '>
      <div >
          <img style={{height:"120px",width:"500px"}} src="src/imgs/diamond logo.png" alt="logo" />
      </div>
    </div>
  )
}

export default Logo