// import Modal from "react-bootstrap/Modal";
// import { useForm } from "react-hook-form";
// import "./connection.css";
// import { API_URL, doApiMethod, TOKEN_KEY } from "../../services/apiServices";
// import { useNavigate } from "react-router-dom";

// function Connection(props) {
//   const {
//     register,
//     handleSubmit: handleSubmitLogin,
//     formState: { errors },
//     reset,
//   } = useForm();
//   const {
//     register: registerRegister,
//     handleSubmit: handleSubmitRegister,
//     formState: { errors: errorsRegister },
//     reset: resetRegister,
//   } = useForm();
//   const nev = useNavigate();

//   const onSub = async (bodydata) => {
//     console.log(bodydata);

//     const data = await doApiMethod(API_URL + "/users/login", "POST", bodydata);
//     localStorage.setItem(TOKEN_KEY, data.token);
//     if (data.role === "admin") {
//       nev("/admin");
//     } else if (data.role === "user") {
//       nev("/");
//       props.onHide();
//     }
//     reset();
//   };

//   const onSubmitRegister = async (bodydata) => {
//     console.log(bodydata);
//     const data = await doApiMethod(API_URL + "/users", "POST", bodydata);
//     console.log(data);
//     resetRegister();
//   };

//   return (
//     <Modal
//       {...props}
//       size="lg"
//       aria-labelledby="contained-modal-title-vcenter"
//       centered
//     >
//       <Modal.Header className="border border-0" closeButton />
//       <div dir="rtl" className="p-3 d-lg-flex justify-content-between">
//         <form className="col-lg-5" onSubmit={handleSubmitLogin(onSub)}>
//           <h2>התחברות</h2>
//           <div>
//             <label className="fw-bold">כתובת איימיל:</label>
//             <input
//               type="email"
//               name="emile"
//               className="form-control  my-2"
//               {...register("email", {
//                 required: "שדה זה הוא חובה.",
//                 pattern: {
//                   value: /^[^@ ]+@[^@ ]+\.[^@ .]{2,}$/,
//                   message: "אימייל אינו תקין",
//                 },
//               })}
//             />
//             {errors.email && (
//               <p className="colertecxt">{errors.email.message}</p>
//             )}
//           </div>
//           <div>
//             <label className="fw-bold">סיסמא:</label>
//             <input
//               type="password"
//               name="password"
//               className="form-control my-2"
//               {...register("password", {
//                 required: true,
//                 validate: {
//                   checkLength: (value) => value.length >= 4,
//                 },
//               })}
//             />
//             {errors.password?.type === "required" && (
//               <p className="colertecxt">שדה זה הוא חובה.</p>
//             )}
//             {errors.password?.type === "checkLength" && (
//               <p className="colertecxt">סיסמה צריכה להכיל לפחות 4 תווים.</p>
//             )}
//           </div>
//           <div>
//             <label className="checkbox mt-3">
//               <input
//                 className="ms-2 "
//                 type="checkbox"
//                 value="remember-me"
//                 name="rememberMe"
//               />
//               זכור אותי
//             </label>
//             <button className="btn btnOn" type="submit">
//               התחברות
//             </button>
//           </div>
//         </form>
//         <form
//           onSubmit={handleSubmitRegister(onSubmitRegister)}
//           className="col-lg-6 mt mt-lg-0"
//         >
//           <h2>הרשמה</h2>
//           <div>
//             <label className="fw-bold">שם משתמש:</label>
//             <input
//               type="text"
//               name="userName"
//               className="form-control my-2"
//               {...registerRegister("userName", {
//                 required: "שדה זה הוא חובה.",
//               })}
//             />
//             {errorsRegister.userName && (
//               <p className="colertecxt">{errorsRegister.userName.message}</p>
//             )}
//           </div>
//           <div>
//             <label className="fw-bold">כתובת איימיל:</label>
//             <input
//               type="email"
//               name="emile"
//               className="form-control  my-2"
//               {...registerRegister("email", {
//                 required: "שדה זה הוא חובה.",
//                 pattern: {
//                   value: /^[^@ ]+@[^@ ]+\.[^@ .]{2,}$/,
//                   message: "אימייל אינו תקין",
//                 },
//               })}
//             />
//             {errorsRegister.email && (
//               <p className="colertecxt">{errorsRegister.email.message}</p>
//             )}
//           </div>
//           <div>
//             <label className="fw-bold">סיסמא:</label>
//             <input
//               type="password"
//               name="password"
//               className="form-control my-2"
//               {...registerRegister("password", {
//                 required: true,
//                 validate: {
//                   checkLength: (value) => value.length >= 4,
//                 },
//               })}
//             />
//             {errorsRegister.password?.type === "required" && (
//               <p className="colertecxt">שדה זה הוא חובה.</p>
//             )}
//             {errorsRegister.password?.type === "checkLength" && (
//               <p className="colertecxt">סיסמה צריכה להכיל לפחות 4 תווים.</p>
//             )}
//           </div>
//           <div>
//             <label className="checkbox mt-3">
//               <input
//                 className="ms-2"
//                 type="checkbox"
//                 value="remember-me"
//                 name="rememberMe"
//               />
//               מאשר\ת קבלת עידכונים למייל
//             </label>
//             <button className="btn btnOn">הרשמה</button>
//           </div>
//         </form>
//       </div>
//     </Modal>
//   );
// }

// export default Connection;


import Modal from "react-bootstrap/Modal";
import Connection from "./connection";
import Enrollment from "./enrollment";
import "./modleconnection.css";


function ModalConnection(props) {
 
  const { show, onHide } = props; // קבלת הפרופסים מהקומפוננטה האב

  return (
    <Modal
    show={show} onHide={onHide}
      size="lg"
      aria-labelledby="contained-modal-title-vcenter"
      centered
     
    >
      <Modal.Header className="border border-0" closeButton />
      <div dir="rtl" className="row p-5 ">
    <div className="col-lg-6 ps-lg-4">   <Connection  onHide={props.onHide}/></div>
      <div className="col-lg-6 pe-lg-4 mt-5 mt-lg-0"> <Enrollment handleLoginSuccess={props.handleLoginSuccess}/></div>
       
      </div>
    </Modal>
  );
}

export default ModalConnection;