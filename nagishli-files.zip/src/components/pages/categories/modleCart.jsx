// import React, { useContext } from "react";
// import { Appcontext } from "../../../context/context";
// import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
// import { faTrash } from "@fortawesome/free-solid-svg-icons";
// import { Link } from "react-router-dom";

// import Offcanvas from "react-bootstrap/Offcanvas";

// const ModleCart = () => {
//   const { cart, removeFromCart, calculateTotal, show, handleClose } =
//     useContext(Appcontext);


//   return (
//     <div>
//       <Offcanvas dir="rtl" show={show} onHide={handleClose}>
//         <Offcanvas.Header closeButton />
//         {cart.length <= 0 ? (
//         <h2 className="py-5 text-center">עגלת הקניות ריקה</h2>
//       ) : (
//         <div style={{ maxHeight: "800px", overflowY: "auto" }}>
//           <h2 className="text-center mb-5">סל קניות</h2>

//           {cart.map((obj, i) => (
//             <div key={i} className="  pb-4">
//               <div className=" d-flex bacColor justify-content-evenly">
//                 <div>
//                   <img
//                     className="imgge"
//                     src={obj.img_url}
//                     alt={obj.name}
//                     height={70}
//                     width={70}
//                   />
//                 </div>
//                 <div className="col-7 ">
//                 {obj.name} 
//                   <div className="d-flex ">
//                     <p className="ms-4"> x {obj.count}</p>
//                     <p>
//                       {obj.price?.toFixed(2)}
//                       <span> ₪</span>
//                     </p>
//                   </div>
//                 </div>
//                 <div className="col-1">
//                   <button
//                     className="btn border-0"
//                     onClick={() => {
//                       removeFromCart(obj);
//                     }}
//                   >
//                     <FontAwesomeIcon icon={faTrash} size="xl" />
//                   </button>
//                 </div>
//               </div>
//             </div>
//           ))}

//           <div className="container text-center">
//             <p className="border-bottom border-top fw-bold p-1">
//               סכום ביינים: {calculateTotal()?.toFixed(2)} ₪
//             </p>
          
            
           
//             <button className="btn btnBtn1 mb-3 col-12" >
//             מעבר לסל הקניות
//           </button>
//           <button className="btn btnBtn1 col-12 mb-3" >
//             מעבר לתשלום
//           </button>
//           </div>
//         </div>)}
//       </Offcanvas>
//     </div>
//   );
// };

// export default ModleCart;






import React, { useContext, useEffect } from "react";
import { Appcontext } from "../../../context/context";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faTrash } from "@fortawesome/free-solid-svg-icons";
import { Link, useNavigate } from "react-router-dom";

import Offcanvas from "react-bootstrap/Offcanvas";
import { Badge } from "react-bootstrap";

const ModleCart = () => {
  const { cart, removeFromCart, calculateTotal, show, handleClose,cartCount } = useContext(
    Appcontext
  );

  const nav = useNavigate();

 

  const beyondToShoppingCart =() => {
    // ספינר
    const event = new Event('updateSpinner');
    window.dispatchEvent(event);
    nav("/shoppingCart");
    handleClose();
  }
  const beyondToPayment =() => {
        // ספינר
        const event = new Event('updateSpinner');
        window.dispatchEvent(event);
    nav("/payment");
    handleClose();
  }



  return (
    <div>
            {/* כאוונטר סל קניות */}
            {cartCount > 0 && (
        <Badge
          pill
          bg="danger"
          style={{
            position: "absolute",
            top: "10px",
            left: "65px",
            fontSize: "8px",
          }}
        >
          {cartCount}
        </Badge>
      )}
      <Offcanvas dir="rtl" show={show} onHide={handleClose}>
        <Offcanvas.Header closeButton />
        <h4 className="text-center">סל קניות</h4>
        {cart.length <= 0 ? (
          <p className="py-4 text-center">אין מוצרים בסל הקניות</p>
        ) : (
          <div style={{ maxHeight: "800px", overflowY: "auto" }}>
            {cart.map((obj, i) => (
              <div key={i} className="  pb-4">
                <div className=" d-flex bacColor justify-content-evenly">
                  <div>
                    <img
                      className="imgge"
                      src={obj.img_url}
                      alt={obj.name}
                      height={70}
                      width={70}
                    />
                  </div>
                  <div className="col-7 ">
                    {obj.name}
                    <div className="d-flex ">
                      <p className="ms-4"> x {obj.count}</p>
                      <p>
                        {obj.price?.toFixed(2)}
                        <span> ₪</span>
                      </p>
                    </div>
                  </div>
                  <div className="col-1">
                    <button
                      className="btn border-0"
                      onClick={() => {
                        removeFromCart(obj);
                      }}
                    >
                      <FontAwesomeIcon icon={faTrash} size="xl" />
                    </button>
                  </div>
                </div>
              </div>
            ))}

            <div className="container text-center">
              <p className="border-bottom border-top fw-bold p-1">
                סכום ביינים: {calculateTotal()?.toFixed(2)} ₪
              </p>
              
                <button onClick={beyondToShoppingCart}  className="btn btnBtn1 mb-3 col-12">מעבר לסל הקניות</button>
             
              <button onClick={beyondToPayment} className="btn btnBtn1 col-12 mb-3">מעבר לתשלום</button>
            </div>
          </div>
        )}
      </Offcanvas>
    </div>
  );
};

export default ModleCart;









