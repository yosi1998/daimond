// import React, { useContext } from "react";
// import { Appcontext } from "../../../context/context";
// import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
// import { faTrash } from "@fortawesome/free-solid-svg-icons";
// import "./app.css";
// import { Link, useNavigate } from "react-router-dom";
// const ShoppingCart = () => {
//   const { cart, removeFromCart } = useContext(Appcontext);

//   return (
//     <div dir="rtl">
//       {cart.length <= 0 ? (
//         <h2 className="py-5 text-center">עגלת הקניות ריקה</h2>
//       ) : (
//         <div className="row pt-5">
//           <div className="col-lg-7">
//             <table className="table ">
//               {cart.length > 0 && (
//                 <thead>
//                   <tr className="borderBottom">
//                     <th>מוצר</th>
//                     <th>מחיר </th>
//                     <th>כמות</th>
//                     <th>סכום ביניים</th>
//                   </tr>
//                 </thead>
//               )}
//               <tbody>
//                 {cart.map((obj, i) => (
//                   <tr key={i} className="table-secondary borderTr ">
//                     <td className="d-flex p-0 align-items-center col">
//                       <button
//                         className="btn border-0"
//                         onClick={() => removeFromCart(obj)}
//                       >
//                         <FontAwesomeIcon icon={faTrash} />
//                       </button>
//                       <img
//                         src={obj.img_url}
//                         alt={obj.name}
//                         width={100}
//                         className="responsive-image"
//                       />
//                       <span className="me-3 d-">{obj.name}</span>
//                     </td>
//                     <td className="align-middle col-2">
//                       {obj.price.toFixed(2)} ₪
//                     </td>
//                     <td className="align-middle col-2">{obj.count}</td>
//                     <td className="align-middle col-2">
//                       {obj.price * obj.count} ₪
//                     </td>
//                   </tr>
//                 ))}
//               </tbody>
//             </table>
//           </div>
//           {cart.length > 0 && <div className="col-lg-5">

//        <Link to="/payment">   <button>מעבר לתשלום</button></Link>
//           </div>}
//         </div>
//       )}
//     </div>
//   );
// };

// export default ShoppingCart;

import React, { useContext } from "react";
import { Appcontext } from "../../../context/context";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faTrash,faArrowRightLong } from "@fortawesome/free-solid-svg-icons";
import "./app.css";
import { Link, useNavigate } from "react-router-dom";
const ShoppingCart = () => {
  const nav = useNavigate();
  const {
    cart,
    calculateTotal,
    removeFromCart,
    selectedShippingOption,
    handleShippingOptionChange,
    shipping1,
    shipping2,
    shippingPrice,
  } = useContext(Appcontext);

const toBack = () =>{
  nav(-1);
}

  return (
    <div dir="rtl">
      {cart.length <= 0 ? (
        <h2 className="py-5 text-center">עגלת הקניות ריקה</h2>
      ) : (
        <div className="row p-5">
          <div className="col-lg-7 ps-lg-4 ps-xl-5">
            <table className="table ">
              {cart.length > 0 && (
                <thead>
                  <tr className="borderBottom">
                    <th>מוצר</th>
                    <th>מחיר </th>
                    <th>כמות</th>
                    <th className="bbttnn">סכום ביניים</th>
                  </tr>
                </thead>
              )}
              <tbody>
                {cart.map((obj, i) => (
                  <tr key={i} className="table-secondary borderTr ">
                    <td className="d-flex p-0 align-items-center col">
                      <button
                        className="btn border-0"
                        onClick={() => removeFromCart(obj)}
                      >
                        <FontAwesomeIcon icon={faTrash} />
                      </button>
                      <img
                        src={obj.img_url}
                        alt={obj.name}
                        width={100}
                        className="responsive-image"
                      />
                      <span className="me-3">{obj.name}</span>
                    </td>
                    <td className="align-middle col-2">
                      {obj.price.toFixed(2)} ₪
                    </td>
                    <td className="align-middle col-2">{obj.count}</td>
                    <td className="align-middle col-2">
                      {obj.price * obj.count} ₪
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
           
          <button onClick={toBack} className="py-2 px-4 continueShopping"><FontAwesomeIcon className="ps-2" icon={faArrowRightLong} />   להמשיך לקנות </button>
          </div>
          <div className="col-lg-5 mt-5 mt-lg-2 pe-lg-4 pe-xl-5  border-end borderEndNane">
            <div className="">
              <h5 className="fw-bold borderBottom pb-2"> סה"ה בסל הקניות</h5>
            </div>
            <div className="d-flex justify-content-between border-bottom  pt-2 mt-4">
              <p className="fs-5">סכום ביניים</p>
              <p className="fsPriceTotle">{calculateTotal().toFixed(2)} ₪</p>
            </div>
            <p className="mt-2 fw-bold">משלוח:</p>
            <div className="border p-3 mt-4 d-flex align-items-center small bgColorRadio">
            
              <div>
                <input
                  className="form-check-input"
                  type="radio"
                  name="exampleRadios"
                  id="exampleRadios1"
                  value="option1"
                  checked={selectedShippingOption === "option1"}
                  onChange={handleShippingOptionChange}
                />
              </div>
              <div>
                <label
                  className="form-check-label me-2"
                  htmlFor="exampleRadios1"
                >
                  <span className="fw-bold">משלוח עד הבית 1-5 ימי עסקים:</span>
                  <span className="pricePayment">{shipping1.toFixed(2)} ₪</span>
                </label>
              </div>
            </div>
            <div className="border p-3 mt-2  d-flex align-items-center justify-content-between small bgColorRadio">
              <div className=" d-flex align-items-center ">
                <div>
                  <input
                    className="form-check-input"
                    type="radio"
                    name="exampleRadios"
                    id="exampleRadios2"
                    value="option2"
                    checked={selectedShippingOption === "option2"}
                    onChange={handleShippingOptionChange}
                  />
                </div>
                <div>
                  <label
                    className="form-check-label me-2"
                    htmlFor="exampleRadios2"
                  >
                    <span className="fw-bold">
                      משלוח אקספרס עד 2 ימי עסקים:
                    </span>
                    <span className="pricePayment">
                      {shipping2.toFixed(2)} ₪
                    </span>
                  </label>
                </div>
              </div>

              <div className="small text-start">
              
                <Link className="linkToCity fw-bold" to="/cityListPage">
                  <span>לחצו לרשימת הערים </span>
                </Link>
              </div>
            </div>
            <div className="d-flex justify-content-between  borderBotom border-top pt-2 mt-4">
              <p className="fw-bold">סה"כ</p>
              <p className="fsPriceTotle">
                {(calculateTotal() + shippingPrice).toFixed(2)} ₪
              </p>
            </div>
            <Link to="/payment">
        
            <button  className="mt-3  btn btn-dark col-12">מעבר לתשלום</button>
            </Link>
          </div>
        </div>
      )}
    </div>
  );
};

export default ShoppingCart;
