// import { useState, useEffect, useContext } from "react";
// import { Appcontext } from "../../../context/context";
// import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
// import { faHeart } from "@fortawesome/free-solid-svg-icons";
// import { Link } from "react-router-dom";
// import { API_URL, doApiGet } from "../../../services/apiServices";
// import "./app.css";
// import { ToastContainer, toast } from 'react-toastify'
// import 'react-toastify/dist/ReactToastify.css'

// const Chains = () => {
//   const [chains, setChains] = useState([]);
//   const { addToCart, addTofavourites,buttonColors,handleClick} = useContext(Appcontext);

//   const showToast = () => {
//     toast.success('Successfully submitted!', {
//       position: toast.POSITION.TOP_CENTER,
//     })
//   }

//   useEffect(() => {
//     const doApi = async () => {
//       try {
//         const _url = API_URL + "/jewelry?category=chains";
//         const data = await doApiGet(_url);
//          console.log(data);
//         setChains(data);
//       } catch (error) {
//         console.log(error);
//       }
//     };
//     setTimeout(() => {
//       doApi();
//     }, 500);
   
//   }, []);

//   return (
//     <div className="container-fluid pt-5">
//       <div className="container text-center">
//         <div className="row g-4 g-md-5 pt-3 pb-5">
//           {chains.map((obj, i) => {
//              const buttonColor = buttonColors[obj._id] ;
//             return (
//               <div key={i} className="col-6 col-lg-4 col-xxl-3">
//                 <div className="card boxs1">
//                   <div className="text-end">
//                   <button
//                       className="btn border border-0 b"
//                       onClick={() => {
//                         addTofavourites(obj);
//                         handleClick(obj._id);
//                       }}
//                     >
//                       <FontAwesomeIcon
//                         icon={faHeart}
//                         size="2xl"
//                         style={{ color: buttonColor}}
//                       />
//                     </button>
//                   </div>
//                   <Link to={`/productInfo/${obj._id}`}>
//                     <img
//                       src={obj.img_url}
//                       className="card-img-top responsive-imag"
//                       alt={obj.name}
                  
//                     />
//                   </Link>
//                   <div className="card-body ">
//                     <h5 style={{ height: "48px" }} className="card-title">
//                       {obj.name}
//                     </h5>
//                     <p className="card-text fw-bold">
//                       {obj.price.toFixed(2)} <span className="fs-5">₪</span>
//                     </p>
//                   </div>

//                   <div >
//                     <button
//                       className="btn1 col-12 py-2 "
//                       onClick={() => addToCart(obj)}
//                     >
//                       הוספה לסל
//                     </button>
//                   </div>
//                 <button onClick={showToast} className="btn2 py-2 px-4 mt-3 mt-md-0">
//                       קניה עכשיו
//                     </button>
                
//                 </div>
//               </div>
//             );
//           })}
//         </div>
//       </div>


//       <ToastContainer />
//     </div>
    
//   );
// };

// export default Chains;






import { useState, useEffect, useContext } from "react";
import { Appcontext } from "../../../context/context";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faHeart } from "@fortawesome/free-solid-svg-icons";
import { Link } from "react-router-dom";
import { API_URL, doApiGet } from "../../../services/apiServices";
import "./app.css";
import { ToastContainer, toast } from 'react-toastify'
import 'react-toastify/dist/ReactToastify.css'

const Chains = () => {
  const [chains, setChains] = useState([]);
  const { addToCart, addTofavourites,buttonColors,handleClick,doApiAddCart} = useContext(Appcontext);

  const showToast = () => {
    toast.success('Successfully submitted!', {
      position: toast.POSITION.TOP_CENTER,
    })
  }

  useEffect(() => {
    const doApi = async () => {
      try {
        const _url = API_URL + "/jewelry?category=chains";
        const data = await doApiGet(_url);
         console.log(data);
        setChains(data);
      } catch (error) {
        console.log(error);
      }
    };
    setTimeout(() => {
      doApi();
    }, 500);
   
  }, []);

  return (
    <div className="container-fluid pt-5">
      <div className="container text-center">
        <div className="row g-4 g-md-5 pt-3 pb-5">
          {chains.map((obj, i) => {
             const buttonColor = buttonColors[obj._id] ;
            return (
              <div key={i} className="col-6 col-lg-4 col-xxl-3">
                <div className="card boxs1">
                  <div className="text-end">
                  <button
                      className="btn border border-0 b"
                      onClick={() => {
                        addTofavourites(obj);
                        handleClick(obj._id);
                      }}
                    >
                      <FontAwesomeIcon
                        icon={faHeart}
                        size="2xl"
                        style={{ color: buttonColor}}
                      />
                    </button>
                  </div>
                  <Link to={`/productInfo/${obj._id}`}>
                    <img
                      src={obj.img_url}
                      className="card-img-top responsive-imag"
                      alt={obj.name}
                  
                    />
                  </Link>
                  <div className="card-body ">
                    <h5 style={{ height: "48px" }} className="card-title">
                      {obj.name}
                    </h5>
                    <p className="card-text fw-bold">
                      {obj.price.toFixed(2)} <span className="fs-5">₪</span>
                    </p>
                  </div>

                  <div >
                    <button
                      className="btn1 col-12 py-2 "
                      onClick={() => doApiAddCart(obj)}
                    >
                      הוספה לסל
                    </button>
                  </div>
                <button onClick={showToast} className="btn2 py-2 px-4 mt-3 mt-md-0">
                      קניה עכשיו
                    </button>
                
                </div>
              </div>
            );
          })}
        </div>
      </div>


      <ToastContainer />
    </div>
    
  );
};

export default Chains;



