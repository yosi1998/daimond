// import AppRouters from "./components/routers/appRouters";
// import { useState } from "react";
// import { Appcontext } from "./context/context";
// import Badge from "react-bootstrap/Badge";
// import "./App.css";
// import WhatsAppButton from "../whatsAppButton";
// import { ToastContainer } from 'react-toastify';
// import 'react-toastify/dist/ReactToastify.css';


// function App() {

//   // עגלת קניות
//   const [cart, setCart] = useState([]);
//   const [cartCount, setCartCount] = useState(0);
//   const [show, setShow] = useState(false);
//   const handleShow = () => setShow(true);
//   const handleClose = () => setShow(false);

//   // מועדפים
//   const [favourites, setFavourites] = useState([]);
//   const [cartCountFavourites, setCartCountFavourites] = useState(0);
//   const [buttonColors, setButtonColors] = useState({});

//   // סל קניות
//   const addToCart = (product) => {
//     const existingProduct = cart.find((item) => item._id === product._id);
//     if (existingProduct) {
//       const updatedCart = cart.map((item) =>
//         item._id === product._id ? { ...item, count: item.count + 1 } : item
//       );
//       setCart(updatedCart);
//     } else {
//       setCart([...cart, { ...product, count: 1 }]);
//     }
//     setCartCount((prevCount) => prevCount + 1);
//   handleShow();
//   };

//   const removeFromCart = (product) => {
//     const updatedCart = cart.map((item) =>
//       item._id === product._id ? { ...item, count: item.count - 1 } : item
//     );
//     const filteredCart = updatedCart.filter((item) => item.count > 0);
//     setCart(filteredCart);
//     setCartCount((prevCount) => prevCount - 1);
//   };

//   const calculateTotal = () => {
//     let total = 0;
//     for (let i = 0; i < cart.length; i++) {
//       total += cart[i].price * cart[i].count;
//     }
//     return total;
//   };

//   //  מועדפים
//   const handleClick = (id) => {
//     const isRed = buttonColors[id] === "red";

//     if (isRed) {
//       removeFromfavourites(id);
//     }

//     setButtonColors((prevColors) => ({
//       ...prevColors,
//       [id]: isRed ? "" : "red",
//     }));
//   };

//   const addTofavourites = (product) => {
//     const productId = product._id;

//     if (buttonColors[productId] === "red") {
//       removeFromfavourites(productId);
//       return;
//     }

//     setFavourites([...favourites, product]);
//     setCartCountFavourites(cartCountFavourites + 1);
//   };

//   const removeFromfavourites = (id) => {
//     const updatedCart = favourites.filter((item) => item._id !== id); // שינוי כאן
//     setFavourites(updatedCart);
//     setCartCountFavourites(updatedCart.length);

//     setButtonColors((prevColors) => ({
//       ...prevColors,
//       [id]: "",
//     }));
//   };


//   // עמוד תשלום
//   const shipping1 = 24.0;
//   const shipping2 = 29.9;
//   const [shippingPrice, setShippingPrice] = useState(shipping1);
//   const [selectedShippingOption, setSelectedShippingOption] =
//     useState("option1");

//     const sumTotlePrice = (calculateTotal() + shippingPrice).toFixed(2);

//     const handleShippingOption = (option) => {
//       if (option === "option1") {
//         setShippingPrice(shipping1);
//       } else if (option === "option2") {
//         setShippingPrice(shipping2);
//       }
//     };
  
//     const handleShippingOptionChange = (event) => {
//       setSelectedShippingOption(event.target.value);
//       handleShippingOption(event.target.value); // קריאה לפונקציה handleShippingOption כאשר מתבצע שינוי בבחירת המשתמש
//     };
//   return (
//     <div dir="rtl">
    
//       {/* כאוונטר סל קניות */}
//       {cartCount > 0 && (
//         <Badge
//           pill
//           bg="danger"
//           style={{
//             position: "absolute",
//             top: "10px",
//             left: "65px",
//             fontSize: "8px",
//           }}
//         >
//           {cartCount}
//         </Badge>
//       )}
//       {/* כאוונטר מועדפים */}
//       {cartCountFavourites > 0 && (
//         <Badge
//           pill
//           bg="danger"
//           style={{
//             position: "absolute",
//             top: "11px",
//             left: "132px",
//             fontSize: "8px",
//           }}
//         >
//           {cartCountFavourites}
//         </Badge>
//       )}

//       <Appcontext.Provider
//         value={{
//           // סל קניות
//           addToCart,
//           cartCount,
//           cart,
//           removeFromCart,
//           show,
//           calculateTotal,
//           handleClose,
//           handleShow,
//           // מועדפים
//           addTofavourites,
//           buttonColors,
//           handleClick,
//           favourites,
//           removeFromfavourites,
//           // עמוד תשלום
//           selectedShippingOption,
//           handleShippingOption,
//           handleShippingOptionChange,
//           shipping1,
//           shipping2,
//           shippingPrice,
//           sumTotlePrice
//         }}
//       >

//         <AppRouters />
//         <ToastContainer />
//         <WhatsAppButton />
//       </Appcontext.Provider>
 
//     </div>
//   );
// }

// export default App;







import AppRouters from "./components/routers/appRouters";
import { useEffect, useState } from "react";
import { Appcontext } from "./context/context";
import Badge from "react-bootstrap/Badge";
import "./App.css";
import WhatsAppButton from "../whatsAppButton";
import { ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import { doApiMethod,API_URL ,TOKEN_KEY} from "./services/apiServices";


function App() {

  // עגלת קניות
  const [cart, setCart] = useState([]);
  const [cartCount, setCartCount] = useState(0);
  const [show, setShow] = useState(false);
  const handleShow = () => setShow(true);
  const handleClose = () => setShow(false);

  // מועדפים
  const [favourites, setFavourites] = useState([]);
  const [cartCountFavourites, setCartCountFavourites] = useState(0);
  const [buttonColors, setButtonColors] = useState({});



  const doApiAddCart = async (product) => {

    try {
      if (!localStorage[TOKEN_KEY]) {
        toast.info("נראה שאתה לא מחובר", {
          position: "top-center",
          autoClose: 1000,
          hideProgressBar: false,
          closeOnClick: true,
          pauseOnHover: false,
          draggable: true,
          progress: undefined,
          theme: "dark",
        });
      }
      else {
        const url = API_URL + "/users/updateFavs";
        const data = await doApiMethod(url, "PATCH", { favs_ar: [...cart, product] });
       
        console.log(data);
        if (data.modifiedCount) {
          toast.success("המוצר נוסף בהצלחה !", {
            position: "top-center",
            autoClose: 1800,
            hideProgressBar: false,
            closeOnClick: true,
            pauseOnHover: false,
            draggable: true,
            progress: undefined,
            theme: "dark",
          });
        }
      }
    }
    catch (error) {
      console.log(error);
    }
  }

  // סל קניות
  const fetchUserCart = async () => {
    try {
      const url = API_URL + "/users/updateFavs";
      await doApiMethod(url, "PATCH", { favs_ar: cart });
    } catch (error) {
      console.log(error);
    }
  };

  useEffect(() => {
    fetchUserCart();
  }, [cart]);

  const addToCart = (product) => {
    const existingProduct = cart.find((item) => item._id === product._id);
    if (existingProduct) {
      const updatedCart = cart.map((item) =>
        item._id === product._id ? { ...item, count: item.count + 1 } : item
      );
      setCart(updatedCart);
    } else {
      setCart([...cart, { ...product, count: 1 }]);
    }
  };

  const removeFromCart = (product) => {
    const updatedCart = localCart.map((item) =>
      item._id === product._id ? { ...item, count: item.count - 1 } : item
    );
    const filteredCart = updatedCart.filter((item) => item.count > 0);
    setCart(filteredCart);
  };

  useEffect(() => {
    // Update the cart in the context with the localCart when localCart changes
    setCart(cart);
  }, [cart]);

  const calculateTotal = () => {
    let total = 0;
    for (let i = 0; i < cart.length; i++) {
      total += cart[i].price * cart[i].count;
    }
    return total;
  };

  //  מועדפים
  const handleClick = (id) => {
    const isRed = buttonColors[id] === "red";

    if (isRed) {
      removeFromfavourites(id);
    }

    setButtonColors((prevColors) => ({
      ...prevColors,
      [id]: isRed ? "" : "red",
    }));
  };

  const addTofavourites = (product) => {
    const productId = product._id;

    if (buttonColors[productId] === "red") {
      removeFromfavourites(productId);
      return;
    }

    setFavourites([...favourites, product]);
    setCartCountFavourites(cartCountFavourites + 1);
  };

  const removeFromfavourites = (id) => {
    const updatedCart = favourites.filter((item) => item._id !== id); // שינוי כאן
    setFavourites(updatedCart);
    setCartCountFavourites(updatedCart.length);

    setButtonColors((prevColors) => ({
      ...prevColors,
      [id]: "",
    }));
  };


  // עמוד תשלום
  const shipping1 = 24.0;
  const shipping2 = 29.9;
  const [shippingPrice, setShippingPrice] = useState(shipping1);
  const [selectedShippingOption, setSelectedShippingOption] =
    useState("option1");

    const sumTotlePrice = (calculateTotal() + shippingPrice).toFixed(2);

    const handleShippingOption = (option) => {
      if (option === "option1") {
        setShippingPrice(shipping1);
      } else if (option === "option2") {
        setShippingPrice(shipping2);
      }
    };
  
    const handleShippingOptionChange = (event) => {
      setSelectedShippingOption(event.target.value);
      handleShippingOption(event.target.value); // קריאה לפונקציה handleShippingOption כאשר מתבצע שינוי בבחירת המשתמש
    };
  return (
    <div dir="rtl">
    



      <Appcontext.Provider
        value={{
          // סל קניות
          doApiAddCart,
          addToCart,
          cartCount,
          cart,
          removeFromCart,
          show,
          calculateTotal,
          handleClose,
          handleShow,
          fetchUserCart,
          // מועדפים
          addTofavourites,
          buttonColors,
          handleClick,
          favourites,
          removeFromfavourites,
          // עמוד תשלום
          selectedShippingOption,
          handleShippingOption,
          handleShippingOptionChange,
          shipping1,
          shipping2,
          shippingPrice,
          sumTotlePrice
        }}
      >

        <AppRouters />
        <ToastContainer />
        <WhatsAppButton />
      </Appcontext.Provider>
 
    </div>
  );
}

export default App;





