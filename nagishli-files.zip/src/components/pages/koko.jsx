// import React from 'react'
// import { useContext, useState } from "react";
// import { Appcontext } from "../../context/context";
// import { Link, useNavigate } from "react-router-dom";

// const Koko = () => {
//   const { cart, calculateTotal } = useContext(Appcontext);
//   const shipping1 = 24.0;
//   const shipping2 = 29.9;
//   const [shippingPrice, setShippingPrice] = useState(shipping1);
//   const [selectedShippingOption, setSelectedShippingOption] =
//     useState("option1");

//     const sumTotlePrice = (calculateTotal() + shippingPrice).toFixed(2);

//     const handleShippingOption = (option) => {
//       if (option === "option1") {
//         setShippingPrice(shipping1);
//       } else if (option === "option2") {
//         setShippingPrice(shipping2);
//       }
//     };
  
//     const handleShippingOptionChange = (event) => {
//       setSelectedShippingOption(event.target.value);
//       handleShippingOption(event.target.value); // קריאה לפונקציה handleShippingOption כאשר מתבצע שינוי בבחירת המשתמש
//     };
//   return (
//     <div>
//           <div className="d-flex justify-content-between border-bottom border-top pt-2 mt-4">
//                   <p className="fw-bold">סכום ביניים</p>
//                   <p className="fsPriceTotle">
//                     {calculateTotal().toFixed(2)} ₪
//                   </p>
//                 </div>
//                 <div className="border p-3 mt-4 d-flex align-items-center small bgColorRadio">
//                   <div>
//                     <input
//                       className="form-check-input"
//                       type="radio"
//                       name="exampleRadios"
//                       id="exampleRadios1"
//                       value="option1"
//                       checked={selectedShippingOption === "option1"}
//                       onChange={handleShippingOptionChange}
//                     />
//                   </div>
//                   <div>
//                     <label
//                       className="form-check-label me-2"
//                       htmlFor="exampleRadios1"
//                     >
//                       <span className="fw-bold">
//                         משלוח עד הבית 1-5 ימי עסקים:
//                       </span>
//                       <span className="pricePayment">
//                         {shipping1.toFixed(2)} ₪
//                       </span>
//                     </label>
//                   </div>
//                 </div>
//                 <div className="border p-3 mt-2  d-flex align-items-center justify-content-between small bgColorRadio">
//                   <div className=" d-flex align-items-center ">
//                     <div>
//                       <input
//                         className="form-check-input"
//                         type="radio"
//                         name="exampleRadios"
//                         id="exampleRadios2"
//                         value="option2"
//                         checked={selectedShippingOption === "option2"}
//                         onChange={handleShippingOptionChange}
//                       />
//                     </div>
//                     <div>
//                       <label
//                         className="form-check-label me-2"
//                         htmlFor="exampleRadios2"
//                       >
//                         <span className="fw-bold">
//                           משלוח אקספרס עד 2 ימי עסקים:{" "}
//                         </span>
//                         <span className="pricePayment">
//                           {shipping2.toFixed(2)} ₪
//                         </span>
//                       </label>
//                     </div>
//                   </div>
                  
//                   <div className="small text-start"> <Link className="linkToCity fw-bold" to="/cityListPage"><span>לחצו לרשימת הערים </span> </Link> </div>
//                 </div>
//                 <div className="d-flex justify-content-between  borderBotom border-top pt-2 mt-4">
//                   <p className="fw-bold">סה"כ</p>
//                   <p className="fsPriceTotle">
//                     {(calculateTotal() + shippingPrice).toFixed(2)} ₪
//                   </p>
//                 </div>
//     </div>
//   )
// }

// export default Koko